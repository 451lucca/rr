package com.unilopers.academia.repository;

import com.unilopers.academia.model.ItemMatricula;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemMatriculaRepository extends JpaRepository<ItemMatricula, Long> {
}
