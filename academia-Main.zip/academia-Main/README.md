# Academia
Projeto: O projeto será um mini-ERP para academias, um sistema simples que ajuda a gerenciar alunos, planos e pagamentos.
Ele permitirá cadastrar alunos, controlar mensalidades e registrar presenças.
O objetivo é facilitar o controle da academia e substituir planilhas manuais por um sistema fácil de usar.

Integrantes:
  - Giovane Abrantes Bonache
  - Ramon Camilo Figueiredo 
  - Murilo Eusébio Cortez
  - Lucca Edoardo De Vasconcelos
  - João Miguel Ribeiro Dias Machado
